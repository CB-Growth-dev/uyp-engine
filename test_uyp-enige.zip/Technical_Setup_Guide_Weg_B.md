# Technischer Setup-Guide: Von Accounts zu launchreifer Domain

**Konkrete Reihenfolge, wo du was einrichtest und welche DNS-Einträge bei deiner Domain landen müssen.**

Basis: Der Stack aus dem Action Plan (Supabase für DB+Auth, Vercel fürs Frontend, Railway oder Render fürs Backend, Resend/Postmark für E-Mails, Digistore24/CopeCart/Elopage für Zahlung). Nutzt du andere Tools, sag Bescheid – die Konzepte (welcher Record-Typ wofür) bleiben gleich, nur die Oberflächen ändern sich.

---

## Schritt 0 – Voraussetzung: Zugriff auf deine Domain-Verwaltung

Bevor irgendetwas anderes passiert, brauchst du Zugriff auf die **DNS-Verwaltung** deiner Domain – das ist die Stelle, an der du später alle Einträge einträgst.

- [ ] Prüfen: Bei welchem Anbieter liegt deine Domain (Registrar)? Häufig im DACH-Raum: IONOS, Strato, INWX, Namecheap, GoDaddy, oder die Domain läuft bereits über Cloudflare als DNS-Verwalter
- [ ] Login-Zugang zu diesem Verwaltungs-Panel sicherstellen (das brauchst du in jedem folgenden Schritt wieder)
- [ ] Falls noch keine Domain vorhanden: jetzt kaufen (Registrar deiner Wahl, DACH-typisch z.B. IONOS oder INWX)
- [ ] Empfehlung: falls dein aktueller Registrar eine unübersichtliche DNS-Oberfläche hat, Domain-Nameserver auf **Cloudflare** umstellen (kostenloser Plan reicht) – das macht alle folgenden DNS-Einträge deutlich einfacher zu verwalten und ist der De-facto-Standard für genau dieses Setup

---

## Schritt 1 – Anthropic API-Konto (das "Gehirn")

- [ ] Auf **console.anthropic.com** registrieren (falls noch nicht vorhanden)
- [ ] Unter **Settings → Billing** eine Zahlungsmethode hinterlegen
- [ ] Unter **Settings → API Keys** einen neuen API-Key erstellen, sicher notieren (wird gleich als Umgebungsvariable im Backend gebraucht, siehe Schritt 7)
- [ ] Optional, aber empfehlenswert: Ausgabenlimit (Spending Limit) setzen, damit bei einem Bug im Code keine Kostenexplosion passiert

*Kein DNS-Eintrag nötig – die API läuft über deinen Server, nicht über deine Domain direkt.*

---

## Schritt 2 – Code-Repository

- [ ] GitHub-Account (falls nicht vorhanden), neues privates Repository anlegen
- [ ] Dorthin kommt der komplette Code (Backend + Frontend) – Basis für die folgenden Hosting-Schritte, da Vercel/Railway/Render sich direkt mit GitHub verbinden

---

## Schritt 3 – Supabase (Datenbank + Login-System)

- [ ] Account auf **supabase.com** anlegen
- [ ] Neues Projekt erstellen – **Region: Frankfurt (EU)** wählen (wichtig für Datenschutz/DSGVO, siehe frühere Punkte zur Datenresidenz)
- [ ] Unter **Project Settings → API** zwei Werte notieren: `Project URL` und `anon public key` (werden später Umgebungsvariablen)
- [ ] Unter **Authentication → Providers** E-Mail-Login (Magic Link) aktivieren, Passwort-Login deaktivieren (du willst ja Einladungslink statt offener Registrierung, siehe Action Plan Phase 2)
- [ ] Unter **Authentication → URL Configuration** die spätere Domain deiner App eintragen (z.B. `https://app.deinedomain.de`) – das machst du final erst nach Schritt 5, kannst die Einstellung aber jetzt schon vormerken

*Kein DNS-Eintrag bei deiner Domain nötig – Supabase läuft über seine eigene Infrastruktur, du verbindest dich nur per API.*

---

## Schritt 4 – Backend hosten (Railway oder Render)

- [ ] Account auf **railway.app** oder **render.com** anlegen
- [ ] Neues Projekt "aus GitHub-Repository" erstellen, dein Backend-Repo auswählen
- [ ] Unter den Projekt-Einstellungen ("Environment Variables" / "Variables") folgende Werte eintragen:
  - `ANTHROPIC_API_KEY` (aus Schritt 1)
  - `SUPABASE_URL` und `SUPABASE_ANON_KEY` (aus Schritt 3)
  - später auch: E-Mail-API-Key (Schritt 6) und Zahlungsanbieter-Webhook-Secret (Schritt 8)
### Was "Deployment" bedeutet und wie du erkennst, ob es geklappt hat

Ein **Deployment** ist einfach der Vorgang, bei dem Railway/Render deinen Code aus GitHub nimmt, alles Nötige drumherum installiert und ihn startet, sodass er im Internet erreichbar ist. Das passiert automatisch, sobald du dein Repository verknüpfst – und danach bei jedem weiteren Push (jeder neuen hochgeladenen Codeversion) wieder.

**Status bei Railway prüfen:**
1. Im Projekt auf die Kachel deines Services klicken
2. Reiter **"Deployments"** öffnen
3. Der neueste Eintrag zeigt einen Status: **"Building"** (läuft gerade), **"Success"** (grün – geklappt) oder **"Failed"** (rot – Fehler)

**Status bei Render prüfen:**
1. Im Dashboard deinen "Web Service" öffnen
2. Oben steht der Status: **"Live"** (grün – geklappt), **"Deploying"** (läuft) oder **"Deploy failed"** (rot)

**So testest du wirklich, ob es läuft** (unabhängig vom Status-Icon): Railway/Render generiert automatisch eine eigene, kostenlose URL für dein Projekt (z.B. `dein-projekt-production.up.railway.app` bzw. `dein-projekt.onrender.com`), zu finden oben in der Projekt-Übersicht. Diese URL im Browser öffnen – kommt irgendeine Antwort (auch nur simpler Text) statt einer Fehlerseite ("Application Error", "502 Bad Gateway"), war das Deployment erfolgreich. Falls Fehlerseite: meist fehlen Umgebungsvariablen (siehe Liste oben) – im Bereich **"Logs"** der Plattform steht die genaue Fehlermeldung.

> **Häufiger erster Fehler: "Railpack could not detect any language or framework"** – das bedeutet, dein Repository enthält noch keinen echten Anwendungscode (z.B. nur eine README.md). Railway/Render brauchen mindestens eine `package.json` (Node.js) oder `requirements.txt` (Python), um zu erkennen, wie gebaut werden soll. Das ist kein Fehler deinerseits, sondern zu erwarten, solange der eigentliche Backend-Code noch nicht existiert. Zum reinen Testen der Verknüpfung reicht ein minimaler Platzhalter-Server (ein paar Zeilen Code + `package.json`); frag einfach nach, wenn du so eine Testdatei brauchst.

### Wo genau du die eigene Subdomain einträgst

**Bei Railway:** Service anklicken → Reiter **"Settings"** → Abschnitt **"Networking"** → **"Custom Domain"** klicken → Subdomain eintippen, z.B. `api.deinedomain.de`. Railway zeigt danach einen Ziel-Wert an (z.B. `xyz123.up.railway.app`).

**Bei Render:** Web-Service-Dashboard → Reiter **"Settings"** → Abschnitt **"Custom Domains"** → **"Add Custom Domain"** → Subdomain eintragen. Render zeigt ebenfalls einen Ziel-Wert (CNAME) an.

### Wo genau du den DNS-Eintrag dafür anlegst

Das passiert **nicht** bei Railway/Render, sondern bei deiner Domain-Verwaltung aus Schritt 0 (z.B. Cloudflare, IONOS, Strato):
1. Dort einloggen, Bereich **"DNS"** bzw. **"DNS-Einstellungen"** öffnen
2. Neuen Eintrag hinzufügen, Typ **CNAME**
3. Name/Host: `api` (nur der Subdomain-Teil, nicht die ganze Domain)
4. Ziel/Wert: der Wert, den dir Railway/Render angezeigt hat
5. Speichern – kann bis zu ein paar Stunden dauern, bis die Änderung überall "sichtbar" ist (DNS-Propagation)

**Danach prüfen:** `https://api.deinedomain.de` im Browser aufrufen – kommt dieselbe Antwort wie bei der automatisch generierten Railway/Render-URL, hat die Verknüpfung geklappt.

---

## Schritt 5 – Frontend hosten (Vercel)

- [ ] Account auf **vercel.com** anlegen (am einfachsten direkt mit GitHub verbinden)
- [ ] Neues Projekt aus deinem Frontend-Repository importieren
- [ ] Unter **Project Settings → Environment Variables**: die öffentlichen Supabase-Werte (URL + anon key) sowie die Backend-URL (`api.deinedomain.de` aus Schritt 4) eintragen
- [ ] Unter **Project Settings → Domains**: eigene Subdomain hinzufügen, z.B. `app.deinedomain.de`
  - Vercel zeigt dir einen **CNAME-Ziel-Wert** (typisch: `cname.vercel-dns.com`)
  - **→ Bei deiner DNS-Verwaltung:** CNAME-Record anlegen: Name `app`, Ziel = der von Vercel angezeigte Wert
- [ ] Zurück zu Supabase (Schritt 3): jetzt final unter **Authentication → URL Configuration** `https://app.deinedomain.de` als erlaubte Redirect-URL eintragen

*SSL/HTTPS-Zertifikate richten Vercel und Railway/Render automatisch ein, sobald der DNS-Eintrag aktiv ist – dafür musst du nichts extra tun.*

---

## Schritt 6 – Transaktions-E-Mail (Resend oder Postmark)

Für die Einladungs-/Magic-Link-E-Mails nach dem Kauf.

- [ ] Account auf **resend.com** (oder **postmarkapp.com**) anlegen
- [ ] Eigene Domain hinzufügen (z.B. direkt `deinedomain.de` oder eine Subdomain wie `mail.deinedomain.de`)
- [ ] Das Tool zeigt dir daraufhin mehrere **TXT-Records** an, die zur Absender-Verifizierung nötig sind:
  - Ein **SPF-Eintrag** (TXT-Record, meist auf der Root- oder gewählten Subdomain)
  - Ein oder mehrere **DKIM-Einträge** (TXT-Records mit speziellem Namens-Präfix, z.B. `resend._domainkey`)
  - Empfohlen (nicht immer Pflicht): ein **DMARC-Eintrag** (TXT-Record auf `_dmarc.deinedomain.de`)
  - **→ Bei deiner DNS-Verwaltung:** alle vom Tool angezeigten TXT-Records exakt so übernehmen, wie angezeigt (Copy-Paste, keine Tippfehler – sonst schlägt die Verifizierung fehl)
- [ ] Nach Verifizierung (kann einige Minuten bis Stunden dauern): API-Key im Resend/Postmark-Dashboard erstellen
- [ ] Diesen Key als Umgebungsvariable ins Backend eintragen (zurück zu Schritt 4)

---

## Schritt 7 – Zahlungsanbieter (Digistore24, CopeCart oder Elopage)

- [ ] Verkäufer-Account beim gewählten Anbieter anlegen (falls nicht vorhanden), Produkt/Preis anlegen
- [ ] Im Anbieter-Dashboard den Bereich "Webhook" bzw. "IPN" (Instant Payment Notification) suchen
- [ ] Als Ziel-URL deinen Backend-Endpoint eintragen: `https://api.deinedomain.de/webhooks/payment` (die Route, die dein Entwickler/Claude Code im Backend gebaut hat)
- [ ] Das vom Anbieter bereitgestellte **Webhook-Secret** (zur Signaturprüfung, siehe Sicherheitspunkt aus dem Action Plan) kopieren und ebenfalls als Umgebungsvariable ins Backend eintragen
- [ ] Analog einen zweiten Webhook für Rückerstattung/Chargeback einrichten, falls der Anbieter das getrennt anbietet

*Kein DNS-Eintrag nötig – die Verknüpfung läuft rein über die Backend-URL, die in Schritt 4 bereits per DNS erreichbar gemacht wurde.*

---

## Schritt 8 – Rechtliches auf der Domain

- [ ] Impressum-Seite auf der Domain veröffentlichen (in Deutschland/Österreich Pflicht, unabhängig vom Produkt)
- [ ] Datenschutzerklärung veröffentlichen (juristisch geprüft, siehe frühere Punkte zu AVV/DSGVO)
- [ ] AGB, falls vom Zahlungsanbieter nicht bereits mit abgedeckt

*Diese Seiten liegen einfach auf deiner Haupt-Domain oder der App-Subdomain – kein separater DNS-Eintrag, sofern sie Teil der Vercel-App sind.*

---

## Übersichtstabelle: Alle DNS-Einträge auf einen Blick

| Zweck | Typ | Name/Host | Ziel-Wert kommt von |
|---|---|---|---|
| Chat-App (Frontend) | CNAME | `app` | Vercel (nach Domain-Hinzufügen angezeigt) |
| Backend-API | CNAME | `api` | Railway/Render (nach Domain-Hinzufügen angezeigt) |
| E-Mail SPF | TXT | Root oder `mail` | Resend/Postmark |
| E-Mail DKIM | TXT | z.B. `resend._domainkey` | Resend/Postmark |
| E-Mail DMARC (empfohlen) | TXT | `_dmarc` | selbst formuliert oder Tool-Vorschlag |

Alles andere (Supabase, Anthropic, Zahlungsanbieter-Webhook) läuft über API-Keys/URLs, die du in den jeweiligen Umgebungsvariablen einträgst – nicht über deine eigene Domain-DNS.

---

## Reihenfolge im Überblick

```
0. Zugriff auf DNS-Verwaltung sichern (ggf. Cloudflare vorschalten)
1. Anthropic API-Konto + Key
2. GitHub-Repository
3. Supabase-Projekt (EU-Region)
4. Backend deployen (Railway/Render) → api.deinedomain.de per CNAME
5. Frontend deployen (Vercel) → app.deinedomain.de per CNAME
6. E-Mail-Versand verifizieren (Resend/Postmark) → SPF/DKIM/DMARC per TXT
7. Zahlungsanbieter-Webhook auf api.deinedomain.de/webhooks/payment zeigen lassen
8. Rechtliche Seiten veröffentlichen
```

---

## Vor dem Go-Live: letzte technische Checks

- [ ] `https://app.deinedomain.de` lädt korrekt und zeigt Login-Seite
- [ ] Test-Einladungslink per E-Mail kommt an (nicht im Spam-Ordner – falls doch: SPF/DKIM/DMARC nochmal prüfen)
- [ ] Test-Kauf beim Zahlungsanbieter löst tatsächlich Webhook + Account-Erstellung aus
- [ ] Erste Chat-Nachricht an Claude wird korrekt beantwortet, Methoden-Dokument wird sichtbar berücksichtigt
- [ ] Refund-Test: Zugang wird nach simuliertem Rückerstattungs-Webhook gesperrt
